SET SERVEROUTPUT ON;

BEGIN
 
    -- Uncomment the statement you want to test and issue ROLLBACK after testing.

  --add_employee('RUTH','CORES','ST_REP',6100,'RC@email.com');
  --add_employee('RUTH','CORES','SA_REP',6100,'RC@email.com');  

END;
/

/* Uncomment and execute this query to validate the results of the above block. */
/* SELECT *
   FROM employees
   WHERE email = 'RC@email.com';
*/

